package com.lti.layer5.dto;

import com.lti.layer2.entity.CropDetail;
import com.lti.layer2.entity.LiveBid;
import com.lti.layer2.entity.SellRequest;

public class MarketPlaceDto {
	private CropDetail cropDetail; 
	private SellRequest sellRequest;
	private LiveBid liveBid;
	public CropDetail getCropDetail() {
		return cropDetail;
	}
	public void setCropDetail(CropDetail cropDetail) {
		this.cropDetail = cropDetail;
	}
	public SellRequest getSellRequest() {
		return sellRequest;
	}
	public void setSellRequest(SellRequest sellRequest) {
		this.sellRequest = sellRequest;
	}
	public LiveBid getLiveBid() {
		return liveBid;
	}
	public void setLiveBid(LiveBid liveBid) {
		this.liveBid = liveBid;
	}
	
}

package com.lti.layer6.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


import com.lti.layer2.entity.BidderDetail;
import com.lti.layer2.entity.FarmerDetail;
import com.lti.layer2.entity.InsuranceDetail;
import com.lti.layer2.entity.LiveBid;
import com.lti.layer2.entity.SellRequest;
import com.lti.layer4.service.AdminService;
import com.lti.layer4.service.BidderDetailService;
import com.lti.layer4.service.FarmerDetailService;
import com.lti.layer4.service.InsuranceService;
import com.lti.layer4.service.LiveBidService;
import com.lti.layer4.service.LoginService;
import com.lti.layer4.service.RegistrationService;
import com.lti.layer4.service.SellRequestService;
import com.lti.layer5.dto.BidderDto;
import com.lti.layer5.dto.FarmerDto;
import com.lti.layer5.dto.LiveBidDto;
import com.lti.layer5.dto.SellRequestDto;

@RestController
@CrossOrigin
public class Controller {
	
	@Autowired
	FarmerDetailService farmerDetailService;
	
	@Autowired
	LoginService loginService;
	
	@Autowired
	RegistrationService registerService;
	
	@Autowired
	SellRequestService sellRequestService;
	
	@Autowired
	BidderDetailService bidderDetailService;
	
	@Autowired
	LiveBidService liveBidService;
	
	@Autowired
	InsuranceService insuranceService;
	
	@Autowired
	AdminService adminService;
	
	
	
	@GetMapping(path="/getFarmer")
	//@ResponseBody
	public FarmerDetail getFarmer(@RequestBody FarmerDto farmerDto) {
		FarmerDetail farmer = farmerDetailService.findAFarmerService(farmerDto.getFarmerEmail());
		return farmer;
	}
	
	@GetMapping(path="/getFarmers")
	//@ResponseBody
	public List<FarmerDetail> returnFarmers(@RequestBody FarmerDto farmerDto) {
		List<FarmerDetail >farmers;
		try {
			 farmers = farmerDetailService.findAllFarmerService();
			//return farmers;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		return farmerDetailService.findAllFarmerService();
		
		
	}
	
	@GetMapping(path="/isFarmerPresent")
	//@ResponseBody
	public boolean isFarmerPresent(@RequestBody FarmerDto farmerDto) {
		boolean farmers = loginService.isFarmerPresentService(farmerDto.getFarmerEmail(), farmerDto.getPassword());
		return farmers;
	}
	

	@PostMapping(path="/addFarmer")
	//@ResponseBody
	public String addFarmer(@RequestBody FarmerDetail farmerDetail) {
		
		try {
			registerService.addFarmerDetailsService(farmerDetail);
			return "Farmer added Successfully";
		} catch (Exception e) {
			// TODO Auto-generated catch block
			return e.getMessage();
		}
	}
	
	
	
	
	@PostMapping(path="/addBidder")
	//@ResponseBody
	public String addBidder(@RequestBody BidderDetail bidderDetail) {
		
		try {
			registerService.addBidderDetailsService(bidderDetail);
			return "Bidder added Successfully";
		} catch (Exception e) {
			// TODO Auto-generated catch block
			return e.getMessage();
		}
	}
	@GetMapping(path="/getBidder")
	//@ResponseBody
	public BidderDetail getBidder(@RequestBody BidderDto bidderDto) {
		BidderDetail bidder = bidderDetailService.findABidderService(bidderDto.getBidderEmail());
		return bidder;
	}
	
	@GetMapping(path="/getBidders")
	//@ResponseBody
	public List<BidderDetail> getBidders(@RequestBody BidderDto bidderDto) {
		List<BidderDetail >bidders;
		try {
			 bidders = bidderDetailService.findAllBidderService();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		return bidderDetailService.findAllBidderService();

  }
	
	@GetMapping(path="/isBidderPresent")
	//@ResponseBody
	public boolean isBidderPresent(@RequestBody BidderDto bidderDto) {
		boolean bidders = loginService.isBidderPresentService(bidderDto.getBidderEmail(), bidderDto.getPassword());
		return bidders;
	}
	
	@PutMapping(path="/setNewFarmerPassword")
	
	public String setNewFarmerPassword(@RequestBody FarmerDto farmerDto) {
		try {
			loginService.updateFarmerPasswordService(farmerDto.getFarmerEmail(), farmerDto.getPassword());
			return "Password Successfully Updated...";
		} catch (Exception e) {
			// TODO Auto-generated catch block
			return e.getMessage();
		}
	}
	
@PutMapping(path="/setNewBidderPassword")
	
	public String setNewBidderPassword(@RequestBody BidderDto bidderDto) {
		try {
			loginService.updateBidderPasswordService(bidderDto.getBidderEmail(), bidderDto.getPassword());
			return "Password Successfully Updated...";
		} catch (Exception e) {
			// TODO Auto-generated catch block
			return e.getMessage();
		}
	}

	@GetMapping(path="/viewSoldHistory")
	//@ResponseBody
	public List<Object[]> viewSoldHistory(@RequestBody SellRequestDto sellRequestDto) {
	List<Object[] >list;
	try {
		 list = sellRequestService.viewSoldHistoryService();
		//return farmers;
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		
	}
	return sellRequestService.viewSoldHistoryService();
	
	
}
	@GetMapping(path="/getMaxLiveBid")
	//@ResponseBody
	public List<LiveBid> getMaxLiveBid(@RequestBody LiveBidDto liveBidDto) {
		List<LiveBid >maxBid;
		try {
			maxBid = liveBidService.getMaxBidForSellIdService(liveBidDto.getSellId());
			//return farmers;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		return liveBidService.getMaxBidForSellIdService(liveBidDto.getSellId());
		
		
	}
	

	
	
	
	
	@GetMapping(path="/findCropsByFarmer")
	//@ResponseBody
	public List<SellRequest> findCropsByFarmer(@RequestBody SellRequestDto sellRequestDto) {
	List<SellRequest> crops = sellRequestService.getAllCropsOfAFarmerService(sellRequestDto.getFarmerEmail());
	return crops;
	}

	@GetMapping(path="/findFarmersBycrop")
	//@ResponseBody
	public List<SellRequest> findFarmersBycrop(@RequestBody SellRequestDto sellRequestDto)
	{
	List<SellRequest> farmers = sellRequestService.getFarmersForACropService(sellRequestDto.getCropName());
	return farmers;
	}
	
	
	@PostMapping(path="/addInsurance")
	//@ResponseBody
	public String addInsurance(@RequestBody InsuranceDetail insuranceDetail) {
		
		try {
			insuranceService.addInsuranceService(insuranceDetail);
			return "Insurance added Successfully";
		} catch (Exception e) {
			// TODO Auto-generated catch block
			return e.getMessage();
		}
		
	 }
	
	//==================================================================
	//doubtful
	@PostMapping(path="/addSellRequest")
	//@ResponseBody
	public String addSellRequest(@RequestBody SellRequest sellRequest) {
		
		try {
			sellRequestService.addSellRequestService(sellRequest);
			return "Request Placed Successfully";
		} catch (Exception e) {
			// TODO Auto-generated catch block
			return e.getMessage();
		}
		
	 }
	
	@PostMapping(path="/addNewBid")
	//@ResponseBody
	public String addNewBid(@RequestBody LiveBid liveBid) {
		
		try {
			liveBidService.addLiveBidService(liveBid);
			return "New Bid Added Successfully";
		} catch (Exception e) {
			// TODO Auto-generated catch block
			return e.getMessage();
		}
		
	 }
	
	@GetMapping(path="/getsellRequests")
	//@ResponseBody
	public List<SellRequest> getsellRequests(@RequestBody SellRequestDto sellRequestDto) {
		List<SellRequest >requests;
		try {
			requests = adminService.getAllSellRequestsService();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		return adminService.getAllSellRequestsService();

  }
	
@PutMapping(path="/updateRequestStatus")
	
	public String updateRequestStatus(@RequestBody SellRequestDto sellRequestDto) {
		try {
			adminService.updateApprovalRequestService(sellRequestDto.getSellId(), sellRequestDto.getSellReqStatus());
			return "Sell Request Status Updated...";
		} catch (Exception e) {
			// TODO Auto-generated catch block
			return e.getMessage();
		}
	}
	
	@DeleteMapping(path="/deleteRequest")
	public String deleteRequest(@RequestBody SellRequestDto sellRequestDto) {
	// TODO Auto-generated method stub
	try {
		adminService.deleteSellRequestService(sellRequestDto.getSellId());
		return "Request deleted succesfully";
	} catch (Exception e) {
		// TODO Auto-generated catch block
		return e.getMessage();
	}
}
	
}
